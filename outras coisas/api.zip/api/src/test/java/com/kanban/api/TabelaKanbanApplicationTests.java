package com.kanban.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TabelaKanbanApplicationTests {

	@Test
	void contextLoads() {
	}

}
